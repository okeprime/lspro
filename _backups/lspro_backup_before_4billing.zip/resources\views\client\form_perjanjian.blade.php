@extends('layouts.app')

@section('title', 'Lengkapi Perjanjian Sertifikasi')

@section('content')
<div class="container py-4">
    <div class="card border-0 shadow-sm rounded-4">
        <div class="card-body p-4 p-md-5">
            <h4 class="fw-bold mb-2">Formulir Perjanjian Sertifikasi</h4>
            <p class="text-muted mb-4">Silakan periksa dan lengkapi data untuk Perjanjian Sertifikasi (Form 4.1.2) sebelum men-generate dokumen resmi.</p>

            <form action="{{ route('pengajuan.perjanjian.generate', $pengajuan->id) }}" method="POST">
                @csrf
                
                <h5 class="fw-bold text-success mb-3"><i class="fa-solid fa-users me-2"></i>Data Pihak Pertama (LS Pro)</h5>
                <div class="row g-3 mb-4">
                    <div class="col-md-12">
                        <label class="form-label fw-semibold">Nama Pejabat / Pihak Pertama <span class="text-danger">*</span></label>
                        <input type="text" name="pihak_pertama" class="form-control bg-light" value="{{ $pengajuan->nama_tu ?? 'Kepala BBPM SDLP' }}" required>
                        <small class="text-muted">ex officio Kepala BBPM SDLP selaku Ketua Pihak Pertama.</small>
                    </div>
                </div>

                <h5 class="fw-bold text-success mb-3"><i class="fa-solid fa-building me-2"></i>Data Pihak Kedua (Klien)</h5>
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Nama Perusahaan <span class="text-danger">*</span></label>
                        <input type="text" name="pihak_kedua" class="form-control" value="{{ $formData['nama_perusahaan'] ?? $pengajuan->user->nama_perusahaan ?? '' }}" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Nama Wakil Pihak Kedua <span class="text-danger">*</span></label>
                        <input type="text" name="wakil_pihak_kedua" class="form-control" value="{{ $formData['nama_pemohon'] ?? $pengajuan->user->name ?? '' }}" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Jabatan Wakil <span class="text-danger">*</span></label>
                        <input type="text" name="jabatan_wakil" class="form-control" value="{{ $formData['jabatan_pemohon'] ?? 'Direktur Utama' }}" required>
                    </div>
                    <div class="col-md-12">
                        <label class="form-label fw-semibold">Alamat Perusahaan <span class="text-danger">*</span></label>
                        <textarea name="alamat_pihak_kedua" rows="2" class="form-control" required>{{ $formData['alamat_kantor'] ?? '' }}</textarea>
                    </div>
                </div>

                <h5 class="fw-bold text-success mb-3"><i class="fa-solid fa-box me-2"></i>Data Produk & SNI</h5>
                <div class="row g-3 mb-4">
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Nama Produk <span class="text-danger">*</span></label>
                        <input type="text" name="nama_produk" class="form-control" value="{{ $formData['nama_produk'] ?? '' }}" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Lokasi Produk / Pabrik <span class="text-danger">*</span></label>
                        <input type="text" name="lokasi_produk" class="form-control" value="{{ $formData['kota_pabrik'] ?? '' }}" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-semibold">Nomor SNI <span class="text-danger">*</span></label>
                        <input type="text" name="no_sni" class="form-control" value="{{ $formData['no_sni'] ?? '' }}" required>
                    </div>
                    <div class="col-md-8">
                        <label class="form-label fw-semibold">Judul SNI <span class="text-danger">*</span></label>
                        <input type="text" name="judul_sni" class="form-control" value="{{ $formData['judul_sni'] ?? '' }}" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Tipe Skema Sertifikasi <span class="text-danger">*</span></label>
                        <input type="text" name="tipe_skema" class="form-control" value="Tipe 5" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-semibold">Dokumen Regulasi Acuan <span class="text-danger">*</span></label>
                        <input type="text" name="regulasi" class="form-control" value="Permentan" required>
                    </div>
                </div>

                <div class="d-flex justify-content-end gap-2 mt-5">
                    <a href="{{ route('aktivitas.index') }}" class="btn btn-light px-4 py-2 border rounded-3 fw-bold">Kembali</a>
                    <button type="submit" class="btn btn-success px-4 py-2 rounded-3 fw-bold">
                        <i class="fa-solid fa-file-signature me-2"></i> Simpan & Generate Dokumen
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection
