import React from 'react';
import { Head, Link, useForm } from '@inertiajs/react';
import { motion } from 'framer-motion';

export default function Register({ errors: serverErrors }) {
    const { data, setData, post, processing, errors } = useForm({
        nama_perusahaan: '',
        nama_penghubung: '',
        no_telp: '',
        email: '',
        password: '',
        alamat: '',
    });

    const submit = (e) => {
        e.preventDefault();
        post('/register');
    };

    return (
        <>
            <Head title="Buat Akun - LSPro BRMP">
                <link rel="stylesheet" href="/css/login_style.css" />
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"/>
            </Head>

            <div style={{ display: 'flex', height: '100vh', width: '100%', fontFamily: "'Inter', sans-serif" }}>
                <div className="auth-left">
                    <div className="auth-header">
                        <img src="/assets/kementan.png" alt="Logo Kementan" />
                        <h2>BALAI BESAR PERAKITAN DAN MODERNISASI SUMBER DAYA LAHAN PERTANIAN<br/>
                            <span style={{ fontSize: '10px', fontWeight: 'normal', color: '#64748b' }}>BADAN PERAKITAN DAN MODERNISASI PERTANIAN</span>
                        </h2>
                    </div>

                    <div>
                        <h1 className="auth-title">Buat Akun</h1>
                        <p className="auth-subtitle">Lengkapi formulir di bawah ini untuk mendapatkan akses ke sistem Sertifikasi LSPro.</p>

                        {(serverErrors && Object.keys(serverErrors).length > 0) && (
                            <div style={{ background: '#fee2e2', color: '#ef4444', padding: '12px 15px', borderRadius: '8px', marginBottom: '20px', fontSize: '13px', borderLeft: '4px solid #ef4444' }}>
                                <i className="fa-solid fa-circle-exclamation" style={{ marginRight: '8px' }}></i> Pastikan semua data diisi dengan benar.
                            </div>
                        )}

                        <form onSubmit={submit}>
                            <div className="form-group">
                                <label>Nama Perusahaan/Instansi *</label>
                                <div className="input-icon-wrapper">
                                    <i className="fa-solid fa-building"></i>
                                    <input 
                                        type="text" 
                                        name="nama_perusahaan" 
                                        className="form-control" 
                                        placeholder="Contoh: PT. Alam Jaya" 
                                        value={data.nama_perusahaan}
                                        onChange={(e) => setData('nama_perusahaan', e.target.value)}
                                        required 
                                    />
                                </div>
                                {errors.nama_perusahaan && <span style={{ color: '#ef4444', fontSize: '12px', marginTop: '5px', display: 'block' }}>{errors.nama_perusahaan}</span>}
                            </div>

                            <div className="form-group">
                                <label>Nama Penghubung (PIC) *</label>
                                <div className="input-icon-wrapper">
                                    <i className="fa-solid fa-user"></i>
                                    <input 
                                        type="text" 
                                        name="nama_penghubung" 
                                        className="form-control" 
                                        placeholder="Contoh: John Doe" 
                                        value={data.nama_penghubung}
                                        onChange={(e) => setData('nama_penghubung', e.target.value)}
                                        required 
                                    />
                                </div>
                                {errors.nama_penghubung && <span style={{ color: '#ef4444', fontSize: '12px', marginTop: '5px', display: 'block' }}>{errors.nama_penghubung}</span>}
                            </div>

                            <div className="form-group">
                                <label>No. Telp/HP *</label>
                                <div className="input-icon-wrapper">
                                    <i className="fa-solid fa-phone"></i>
                                    <input 
                                        type="text" 
                                        name="no_telp" 
                                        className="form-control" 
                                        placeholder="Contoh: 08123456789" 
                                        value={data.no_telp}
                                        onChange={(e) => setData('no_telp', e.target.value)}
                                        required 
                                    />
                                </div>
                                {errors.no_telp && <span style={{ color: '#ef4444', fontSize: '12px', marginTop: '5px', display: 'block' }}>{errors.no_telp}</span>}
                            </div>

                            <div className="form-group">
                                <label>E-mail *</label>
                                <div className="input-icon-wrapper">
                                    <i className="fa-solid fa-envelope"></i>
                                    <input 
                                        type="email" 
                                        name="email" 
                                        className="form-control" 
                                        placeholder="contoh@mail.dev" 
                                        value={data.email}
                                        onChange={(e) => setData('email', e.target.value)}
                                        required 
                                    />
                                </div>
                                {errors.email && <span style={{ color: '#ef4444', fontSize: '12px', marginTop: '5px', display: 'block' }}>{errors.email}</span>}
                            </div>

                            <div className="form-group">
                                <label>Password *</label>
                                <div className="input-icon-wrapper">
                                    <i className="fa-solid fa-lock"></i>
                                    <input 
                                        type="password" 
                                        name="password" 
                                        className="form-control" 
                                        placeholder="Minimal 6 karakter" 
                                        value={data.password}
                                        onChange={(e) => setData('password', e.target.value)}
                                        required 
                                    />
                                </div>
                                {errors.password && <span style={{ color: '#ef4444', fontSize: '12px', marginTop: '5px', display: 'block' }}>{errors.password}</span>}
                            </div>

                            <div className="form-group">
                                <label>Alamat Lengkap *</label>
                                <div className="input-icon-wrapper">
                                    <i className="fa-solid fa-map-location-dot"></i>
                                    <input 
                                        type="text" 
                                        name="alamat" 
                                        className="form-control" 
                                        placeholder="Masukkan alamat perusahaan..." 
                                        value={data.alamat}
                                        onChange={(e) => setData('alamat', e.target.value)}
                                        required 
                                    />
                                </div>
                                {errors.alamat && <span style={{ color: '#ef4444', fontSize: '12px', marginTop: '5px', display: 'block' }}>{errors.alamat}</span>}
                            </div>

                            <div className="form-group" style={{ marginTop: '25px' }}>
                                <label>Pakta Integritas</label>
                                <div style={{ height: '85px', overflowY: 'auto', border: '1.5px solid #e2e8f0', borderRadius: '10px', padding: '12px', fontSize: '12px', color: '#475569', background: '#f8fafc', marginBottom: '12px', lineHeight: 1.6 }}>
                                    <strong>KEMENTERIAN PERTANIAN - PAKTA INTEGRITAS</strong><br/>
                                    Saya yang mendaftar di sistem ini menyatakan sebagai berikut:<br/>
                                    1. Berperan secara pro aktif dalam upaya pencegahan dan pemberantasan Korupsi, Kolusi, dan Nepotisme serta tidak melibatkan diri dalam perbuatan tercela.<br/>
                                    2. Tidak meminta atau menerima pemberian secara langsung atau tidak langsung berupa suap, hadiah, bantuan, atau bentuk lainnya yang tidak sesuai dengan ketentuan yang berlaku.
                                </div>
                                <label style={{ display: 'flex', alignItems: 'flex-start', gap: '10px', fontWeight: 'normal', cursor: 'pointer', fontSize: '13px', color: '#334155' }}>
                                    <input type="checkbox" required style={{ width: '18px', height: '18px', cursor: 'pointer', marginTop: '2px' }} />
                                    <span>Saya telah membaca, memahami, dan menyetujui isi Pakta Integritas di atas.</span>
                                </label>
                            </div>

                            <motion.button 
                                whileHover={{ scale: 1.05 }}
                                type="submit" 
                                className="btn-auth"
                                disabled={processing}
                            >
                                Daftar Sekarang &rarr;
                            </motion.button>
                        </form>

                        <p style={{ textAlign: 'center', marginTop: '30px', fontSize: '14px', color: '#64748b' }}>
                            Sudah punya akun? <Link href="/login" style={{ color: '#2563eb', fontWeight: 600, textDecoration: 'none' }}>Masuk di sini</Link>
                        </p>
                    </div>
                </div>

                <div className="auth-right"></div>
            </div>
        </>
    );
}
