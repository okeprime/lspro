<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Pengajuan;

class PpcController extends Controller
{
    public function dashboard()
    {
        // PPC melihat tugas pengambilan contoh
        $pengajuans = Pengajuan::with('user')
            ->whereIn('status', ['menunggu_persetujuan_jadwal', 'proses_audit', 'menunggu_lhp'])
            ->whereNotNull('tanggal_pengambilan_contoh')
            ->orderBy('tanggal_pengambilan_contoh', 'asc')
            ->get();
            
        return view('ppc.dashboard', compact('pengajuans'));
    }
}
