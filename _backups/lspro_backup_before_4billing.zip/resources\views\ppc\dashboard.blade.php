@extends('layouts.app')
@section('title', 'Dashboard Petugas Pengambil Contoh (PPC)')

@section('content')
<div class="container-fluid py-3 px-3 px-md-4">
    <div class="mb-4 d-flex justify-content-between align-items-center flex-wrap gap-2">
        <div>
            <h2 style="color: #1e293b; font-weight: 700; letter-spacing: -0.5px; margin-bottom: 4px;">Tugas Pengambilan Contoh</h2>
            <p class="text-muted small mb-0">Jadwal Pengambilan Contoh oleh PPC (Petugas Pengambil Contoh).</p>
        </div>
    </div>

    @if(session('success'))
        <div class="alert alert-success alert-dismissible fade show border-0 shadow-sm p-3 mb-4" role="alert" style="border-radius: 12px; background-color: #f0fdf4; color: #166534;">
            <i class="bi bi-check-circle-fill me-2 fs-5 text-success"></i> <strong>Sukses!</strong> {{ session('success') }}
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <div class="card border-0 shadow-sm" style="border-radius: 16px; overflow: hidden;">
        <div class="card-header bg-white py-3 border-bottom d-flex justify-content-between align-items-center">
            <h5 class="mb-0 fw-bold" style="color: #1e293b; font-size: 1rem;">
                <i class="fa-solid fa-vial text-primary me-2"></i> Daftar Jadwal Pengambilan Contoh
            </h5>
            <span class="badge bg-primary rounded-pill">{{ $pengajuans->count() }} Tugas</span>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0" style="font-size: 14px;">
                    <thead class="table-light">
                        <tr>
                            <th class="ps-4 py-3 text-secondary text-uppercase" style="font-size: 11px; font-weight: 700;">ID Pengajuan</th>
                            <th class="py-3 text-secondary text-uppercase" style="font-size: 11px; font-weight: 700;">Klien / Perusahaan</th>
                            <th class="py-3 text-secondary text-uppercase" style="font-size: 11px; font-weight: 700;">Jadwal Audit</th>
                            <th class="py-3 text-secondary text-uppercase" style="font-size: 11px; font-weight: 700;">Jadwal PPC</th>
                            <th class="py-3 text-secondary text-uppercase" style="font-size: 11px; font-weight: 700;">Status Persetujuan</th>
                            <th class="pe-4 py-3 text-secondary text-uppercase" style="font-size: 11px; font-weight: 700;">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse($pengajuans as $item)
                            <tr>
                                <td class="ps-4 fw-bold" style="color: #475569;">#{{ str_pad($item->id, 5, '0', STR_PAD_LEFT) }}</td>
                                <td>
                                    <div class="fw-bold" style="color: #1e293b;">{{ $item->user->name }}</div>
                                    <div class="text-muted small">{{ $item->user->email }}</div>
                                </td>
                                <td>
                                    <span class="badge bg-light text-dark border"><i class="fa-solid fa-calendar me-1"></i> {{ \Carbon\Carbon::parse($item->jadwal_audit)->translatedFormat('d M Y') }}</span>
                                </td>
                                <td>
                                    <span class="badge bg-info text-dark"><i class="fa-solid fa-vial me-1"></i> {{ \Carbon\Carbon::parse($item->tanggal_pengambilan_contoh)->translatedFormat('d M Y') }}</span>
                                </td>
                                <td>
                                    @if($item->is_jadwal_disetujui === 1)
                                        <span class="badge bg-success"><i class="fa-solid fa-check me-1"></i> Klien Setuju</span>
                                    @elseif($item->is_jadwal_disetujui === 0)
                                        <span class="badge bg-danger"><i class="fa-solid fa-xmark me-1"></i> Klien Menolak</span>
                                    @else
                                        <span class="badge bg-warning text-dark"><i class="fa-solid fa-clock me-1"></i> Menunggu Klien</span>
                                    @endif
                                </td>
                                <td class="pe-4">
                                    <a href="{{ route('aktivitas.show', $item->id) }}" class="btn btn-sm btn-outline-primary" style="border-radius: 8px; font-size: 12px; font-weight: 600;">
                                        <i class="fa-solid fa-eye me-1"></i> Detail
                                    </a>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="6" class="text-center py-5 text-muted">
                                    <div class="py-3">
                                        <i class="fa-solid fa-calendar-check d-block mb-2 text-secondary fs-2"></i>
                                        <span style="font-size: 14px; font-weight: 500;">Belum ada jadwal pengambilan contoh.</span>
                                    </div>
                                </td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
@endsection
