<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Perjanjian Sertifikasi</title>
    <style>
        body {
            font-family: 'Times New Roman', Times, serif;
            font-size: 12pt;
            line-height: 1.5;
            margin: 0;
            padding: 0;
            background: #e2e8f0;
        }
        .page {
            width: 210mm;
            min-height: 297mm;
            padding: 20mm;
            margin: 10mm auto;
            border: 1px solid #D3D3D3;
            border-radius: 5px;
            background: white;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
            position: relative;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .header h3 {
            margin: 0;
            font-size: 14pt;
            text-transform: uppercase;
        }
        .title {
            text-align: center;
            font-weight: bold;
            font-size: 14pt;
            margin: 30px 0 10px 0;
        }
        .nomor {
            text-align: center;
            margin-bottom: 30px;
        }
        .content {
            text-align: justify;
        }
        .pasal-title {
            text-align: center;
            font-weight: bold;
            margin-top: 20px;
        }
        .footer-ttd {
            margin-top: 50px;
            width: 100%;
        }
        .footer-ttd td {
            text-align: center;
            width: 50%;
            vertical-align: bottom;
            padding-top: 80px;
        }
        .form-kode {
            position: absolute;
            bottom: 20mm;
            right: 20mm;
            font-size: 10pt;
        }
        .revisi {
            position: absolute;
            bottom: 20mm;
            left: 20mm;
            font-size: 10pt;
        }
        .btn-print {
            position: fixed;
            top: 20px;
            right: 20px;
            background: #16a34a;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 8px;
            font-family: sans-serif;
            font-weight: bold;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        @media print {
            body { background: white; }
            .page { margin: 0; border: none; border-radius: 0; width: auto; min-height: auto; box-shadow: none; padding: 15mm; }
            .btn-print { display: none; }
            .page-break { page-break-before: always; }
        }
        ol { padding-left: 20px; margin-top: 5px; }
        li { margin-bottom: 5px; }
        .identitas { width: 100%; margin-bottom: 15px; }
        .identitas td { vertical-align: top; }
        .identitas td:first-child { width: 30px; }
    </style>
</head>
<body>
    <button onclick="window.print()" class="btn-print">🖨️ Cetak / Simpan PDF</button>

    @php
        $p = $formData['perjanjian'] ?? [];
        $hari = \Carbon\Carbon::now()->translatedFormat('l');
        $tanggal = \Carbon\Carbon::now()->translatedFormat('d');
        $bulan = \Carbon\Carbon::now()->translatedFormat('F');
        $tahun = \Carbon\Carbon::now()->translatedFormat('Y');
    @endphp

    <div class="page">
        <div class="header">
            <h3>KOP SURAT</h3>
            <hr style="border: 1px solid black; margin-top: 10px;">
        </div>
        
        <div class="title">PERJANJIAN SERTIFIKASI</div>
        <div class="nomor">Nomor : {{ sprintf('PRJ/LSPRO/%s/%05d', $tahun, $pengajuan->id) }}</div>

        <div class="content">
            <p>Pada hari ini <b>{{ $hari }}</b>, tanggal <b>{{ $tanggal }}</b> bulan <b>{{ $bulan }}</b> tahun <b>{{ $tahun }}</b>, kami yang bertanda tangan di bawah ini :</p>
            
            <table class="identitas">
                <tr>
                    <td>a.</td>
                    <td>
                        Pihak Pertama, <b>{{ $p['pihak_pertama'] ?? 'Kepala BBPM SDLP' }}</b> yang beralamat di Jl. Tentara Pelajar No 12 Cimanggu, Bogor 16114 dan dalam hal ini diwakili oleh <b>{{ $p['pihak_pertama'] ?? 'Kepala BBPM SDLP' }}</b> (ex officio Kepala BBPM SDLP) selaku Ketua Pihak Pertama.
                    </td>
                </tr>
                <tr>
                    <td>b.</td>
                    <td>
                        Pihak Kedua, <b>{{ $p['pihak_kedua'] ?? '' }}</b> yang beralamat di <b>{{ $p['alamat_pihak_kedua'] ?? '' }}</b> dan dalam hal ini diwakili oleh <b>{{ $p['wakil_pihak_kedua'] ?? '' }}</b> selaku <b>{{ $p['jabatan_wakil'] ?? '' }}</b>.
                    </td>
                </tr>
            </table>

            <p>Pihak Pertama dan Pihak Kedua sepakat perjanjian ini dibuat dalam ruang lingkup proses sertifikasi kesesuaian oleh Pihak Pertama kepada Pihak Kedua. Pihak pertama memberikan sertifikat kepada pihak kedua yang menerima sertifikasi kesesuaian untuk lingkup sertifikasi sebagaimana tercantum dalam lampiran perjanjian ini.</p>
            
            <p>Apabila dalam pelaksanaan Perjanjian Bersama ini Para Pihak merasa perlu melakukan perubahan, maka perubahan tersebut hanya dapat dilakukan atas kesepakatan Para Pihak yang dituangkan dalam Addendum Perjanjian ini dan merupakan bagian yang tidak dapat dipisahkan dari Perjanjian ini.</p>
            
            <p>Untuk lingkup sertifikasi sebagaimana tercantum dalam lampiran perjanjian ini, dengan kondisi yang diuraikan pada ketentuan-ketentuan berikut.</p>
            
            <div class="pasal-title">Pasal 1<br>Maksud dan Tujuan</div>
            <p>Maksud dan Tujuan perjanjian ini adalah untuk menunjang pelaksanaan Sertifikasi Produk Penggunaan Tanda Kesesuaian SNI produk <b>{{ $p['nama_produk'] ?? '' }}</b> di <b>{{ $p['lokasi_produk'] ?? '' }}</b> sesuai yang dipersyaratkan oleh regulasi.</p>
            
            <div class="pasal-title">Pasal 2<br>Ruang Lingkup</div>
            <p>2.1 Pihak Kedua sepakat untuk mensertifikasikan produknya dengan ruang lingkup <b>{{ $p['no_sni'] ?? '' }}</b> tentang <b>{{ $p['judul_sni'] ?? '' }}</b> sesuai dengan tipe skema <b>{{ $p['tipe_skema'] ?? '' }}</b> mengacu pada dokumen regulasi <b>{{ $p['regulasi'] ?? '' }}</b>.</p>
            <p>2.2 Atas permintaan Pihak Kedua, Pihak Pertama dengan ini sepakat untuk melakukan jasa sertifikasi produk Pihak Kedua atas dasar Standard Nasional Indonesia/SNI terkait guna memperoleh sertifikat produk penggunaan tanda kesesuaian SNI berdasarkan syarat dan aturan sebagaimana diatur dalam perjanjian ini.</p>

        </div>
        
        <div class="revisi">Terbitan/Revisi : 1/-</div>
        <div class="form-kode">FORM 4.1.2 / LS Pro</div>
    </div>

    <div class="page">
        <div class="header">
            <h3>KOP SURAT</h3>
            <hr style="border: 1px solid black; margin-top: 10px;">
        </div>
        <div class="content">
            <div class="pasal-title">Pasal 3<br>Hak dan kewajiban</div>
            <p>3.1 Pihak Kedua setuju untuk menjaga dan mengendalikan kesesuaian produk yang diproduksi dan dipasok olehnya dan telah disertifikasi oleh Pihak Pertama terhadap persyaratan yang ditetapkan dalam standar yang dituliskan dalam perjanjian sertifikasi kesesuaian, sesuai dengan ketentuan umum sertifikasi produk serta aturan khusus yang dinyatakan dalam Dokumen Perjanjian Sertifikasi Kesesuaian termasuk menerapkan perubahan yang sesuai bila perubahan tersebut telah dikomunikasikan oleh Pihak Pertama.</p>
            <p>3.2 Pihak Kedua setuju bahwa personel yang mewakili Pihak Pertama memiliki akses dan tidak dihalangi untuk mengakses pabrik dan atau fasilitas produksi yang berkaitan dengan produk yang tercakup dalam Dokumen Perjanjian Sertifikasi Kesesuaian, dengan atau tanpa pemberitahuan terlebih dahulu selama jam kerja yang normal berlaku pada fasilitas tersebut.</p>
            <p>3.3 Pihak Kedua setuju bahwa produk sebagaimana dimaksud dalam sertifikat kesesuaian akan diproduksi sesuai dengan spesifikasi yang sama dengan contoh atau sampel produk yang telah diperiksa dan diuji serta dinyatakan memenuhi standar yang diacu oleh Pihak Pertama.</p>
            <p>3.4 Pihak Kedua setuju untuk:
                <ol type="a">
                    <li>Setiap saat memenuhi Dokumen Perjanjian Sertifikasi Kesesuaian;</li>
                    <li>Hanya mengklaim bahwa produknya telah disertifikasi sesuai dengan ruang lingkup Sertifikasi Kesesuaian yang dimilikinya;</li>
                    <li>Menerima pengawasan berkala melalui surveilan setiap tahun;</li>
                    <li>Tidak menggunakan Sertifikat Kesesuaian dalam suatu cara yang merusak reputasi Sertifikasi Kesesuaian, dan tidak diperbolehkan untuk membuat pernyataan yang dipertimbangkan oleh Pihak Pertama Kementerian Pertanian adalah tidak benar, serta harus segera mengambil langkah-langkah untuk memperbaiki penggunaan/pernyataan yang tidak benar;</li>
                    <li>Dalam hal terjadi pembatalan dan pencabutan Sertifikat Kesesuaian pada produknya dan mencabut seluruh bahan iklan yang berisikan pengacuan ke Sertifikasi Kesesuaian SNI;</li>
                    <li>Menjelaskan dalam seluruh kontraknya dengan pelanggan bahwa Sertifikat Kesesuaian yang dimilikinya tidak dapat dianggap sebagai sesuatu yang mengurangi tanggung jawab kontrak antara Pihak Kedua dan pelanggannya dalam memasok produk yang konsisten sesuai standar.</li>
                </ol>
            </p>
            
            <div class="pasal-title">Pasal 4<br>Surveilan</div>
            <p>4.1 Pihak Pertama melaksanakan surveilan setiap tahun untuk mengetahui apakah Pihak Kedua melaksanakan kewajibannya sesuai dengan ketentuan umum sertifikasi produk dan ketentuan khusus skema sertifikasi produk, sebagaimana dinyatakan dalam Dokumen Perjanjian Sertifikasi Kesesuaian.</p>
            <p>4.2 Tidak terlaksananya surveilan setiap tahun akibat keengganan Pihak Kedua dapat mengakibatkan pembekuan sertifikat kesesuaian dan pencabutan sertifikat kesesuaian.</p>
        </div>
        <div class="revisi">Terbitan/Revisi : 1/-</div>
        <div class="form-kode">FORM 4.1.2 / LS Pro</div>
    </div>

    <div class="page">
        <div class="header">
            <h3>KOP SURAT</h3>
            <hr style="border: 1px solid black; margin-top: 10px;">
        </div>
        <div class="content">
            <div class="pasal-title">Pasal 5<br>Informasi tentang modifikasi dalam produksi</div>
            <p>Pihak Kedua sebagai penerima sertifikat harus menginformasikan kepada Pihak Pertama selaku LS Pro setiap rencana modifikasi terhadap produk yang dimaksud dalam SPPT SNI, serta terhadap proses produksi dan/atau sistem mutu yang berkaitan dengan produk itu.</p>

            <div class="pasal-title">Pasal 6<br>Penanganan Keluhan</div>
            <p>Pihak Kedua harus memelihara rekaman dari semua keluhan pelanggan yang berkaitan dengan produk yang dicakup dalam Sertifikat Kesesuaian dan melakukan tindakan perbaikan yang sesuai untuk penyelesaian keluhan/pengaduan tersebut. Catatan tersebut tersedia jika diperlukan oleh Pihak Pertama.</p>

            <div class="pasal-title">Pasal 7<br>Publisitas</div>
            <p>7.1 Pihak Kedua berhak mempublikasikan fakta bahwa dia telah diberi wewenang oleh Pihak Pertama untuk membubuhkan tanda kesesuaian bagi produk yang dimaksud dalam Dokumen Perjanjian Sertifikasi Kesesuaian.</p>
            <p>7.2 Pihak Pertama dapat mempublikasikan pemberian, pembatalan dan pencabutan Sertifikat Kesesuaian melalui media umum agar publik dapat mengetahuinya.</p>

            <div class="pasal-title">Pasal 8<br>Kerahasiaan</div>
            <p>Pihak Pertama bertanggung jawab menjamin agar setiap personelnya menjaga kerahasiaan seluruh informasi milik Pihak Kedua yang bersifat rahasia dan diketahui oleh personil tersebut sebagai akibat dari hubungan kerja dengan Pihak Kedua.</p>

            <div class="pasal-title">Pasal 9<br>Pembiayaan Sertifikasi</div>
            <p>Pihak Kedua dikenakan biaya sertifikasi dan surveilen sesuai dengan Peraturan Perundangan yang berlaku.</p>

            <div class="pasal-title">Pasal 10<br>Modifikasi persyaratan produk</div>
            <p>10.1 Apabila ketentuan standar acuan yang tercakup dalam Perjanjian Sertifikasi Kesesuaian direvisi, maka Pihak Pertama harus segera memberitahukan Pihak Kedua melalui surat tercatat (atau ekuivalen), dengan menyebutkan tanggal revisi standar tersebut akan berlaku efektif serta menginformasikan Pihak Kedua tentang dampak dari perubahan tersebut terhadap validitas Sertifikat Kesesuaian yang telah diterbitkan oleh Pihak Pertama, termasuk perlunya dilakukan audit suplemen untuk menilai kesesuaian produk yang terkait terhadap revisi standar itu.</p>
        </div>
        <div class="revisi">Terbitan/Revisi : 1/-</div>
        <div class="form-kode">FORM 4.1.2 / LS Pro</div>
    </div>

    <div class="page">
        <div class="header">
            <h3>KOP SURAT</h3>
            <hr style="border: 1px solid black; margin-top: 10px;">
        </div>
        <div class="content">
            <div class="pasal-title">Pasal 11<br>Pembekuan Sertifikat Kesesuaian SNI</div>
            <p>Sertifikat Kesesuaian dapat dibekukan untuk jangka waktu tertentu, apabila terjadi hal berikut ini :</p>
            <ol type="a">
                <li>Pihak Kedua melakukan perubahan yang menimbulkan ketidaksesuaian terhadap ketentuan.</li>
                <li>Hasil surveilan/pengawasan menunjukkan bahwa kesesuaian produk terhadap ketentuan yang diacu tidak dapat dipertahankan dan ketidaksesuaian yang terjadi tidak dapat diatasi dalam jangka waktu yang ditentukan.</li>
                <li>Surveilan/pengawasan tidak dapat dilakukan setelah diberikan surat peringatan.</li>
                <li>Penyalahgunaan Sertifikat Kesesuaian yang tidak segera diatasi oleh Pihak Kedua dengan melakukan tindakan koreksi/perbaikan yang tepat.</li>
                <li>Pengaduan terhadap Pihak Kedua yang dapat dibuktikan penyimpangannya terhadap Ketentuan dan Tata Cara Perjanjian Sertifikasi Kesesuaian.</li>
                <li>Penyimpangan lainnya terhadap Ketentuan dan Tata Cara Perjanjian Sertifikasi Kesesuaian.</li>
            </ol>

            <div class="pasal-title">Pasal 12<br>Pencabutan Sertifikat Kesesuaian</div>
            <p>12.1 Sertifikat Kesesuaian dapat dicabut apabila terjadi hal berikut ini:
                <ol type="a">
                    <li>Tindakan koreksi/perbaikan yang diambil oleh Produsen tidak memadai dalam kasus penangguhan sertifikat.</li>
                    <li>Surveilan/pengawasan tidak dapat dilakukan setelah diberikan surat pembekuan sertifikat kesesuaian.</li>
                </ol>
            </p>
            <p>12.2 Pencabutan sertifikat kesesuaian hanya dapat dilakukan melalui Komisi Teknis.</p>

            <div class="pasal-title">Pasal 13<br>Pembatalan Sertifikat Kesesuaian</div>
            <p>13.1 Sertifikat Kesesuaian dibatalkan atas permintaan Pihak Kedua.</p>
            <p>13.2 Pembatalan Sertifikasi Kesesuaian hanya dapat dilakukan melalui Komite Sertifikasi.</p>

            <div class="pasal-title">Pasal 14<br>Tanggung Gugat (Liabilitas)</div>
            <p>Penyelesaian masalah yang berkaitan dengan tanggung gugat produk dilakukan berdasarkan peraturan perundangan.</p>
        </div>
        <div class="revisi">Terbitan/Revisi : 1/-</div>
        <div class="form-kode">FORM 4.1.2 / LS Pro</div>
    </div>
    
    <div class="page">
        <div class="header">
            <h3>KOP SURAT</h3>
            <hr style="border: 1px solid black; margin-top: 10px;">
        </div>
        <div class="content">
            <div class="pasal-title">Pasal 15<br>Banding atau perselisihan</div>
            <p>Semua perselisihan yang mungkin timbul dalam kaitannya dengan perjanjian ini diselesaikan sesuai dengan prosedur banding yang ditetapkan oleh Pihak Pertama.</p>

            <div class="pasal-title">Pasal 16<br>Penutup</div>
            <p>Perjanjian ini berlaku dimulai dari ditandatangani perjanjian ini sampai dengan masa sertifikasi dan dibuat dua rangkap, bermaterai cukup, masing-masing mempunyai kekuatan hukum yang sama, satu rangkap untuk PIHAK PERTAMA, dan satu rangkap untuk PIHAK KEDUA, dan masing-masing pihak dapat memperbanyak salinannya sesuai keperluan.</p>

            <table class="footer-ttd">
                <tr>
                    <td>
                        Atas nama Pihak Pertama<br>
                        Penanggung Jawab Mutu
                        <br><br><br><br><br>
                        (.........................................)
                    </td>
                    <td>
                        Atas nama Pihak Kedua<br>
                        <br>
                        <div style="font-size: 9pt; border: 1px solid black; width: 60px; margin: 0 auto; padding: 5px;">
                            Materai<br>Rp 10.000,-
                        </div>
                        <br><br>
                        (.........................................)
                    </td>
                </tr>
            </table>
        </div>
        <div class="revisi">Terbitan/Revisi : 1/-</div>
        <div class="form-kode">FORM 4.1.2 / LS Pro</div>
    </div>

</body>
</html>
